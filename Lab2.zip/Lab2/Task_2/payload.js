cmd = 'msg * Shellcode!';
a = new ActiveXObject('Wscript.Shell');
a.Run(cmd, 0);
