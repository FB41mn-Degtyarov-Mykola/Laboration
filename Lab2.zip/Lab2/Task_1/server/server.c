#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUFFER_SIZE 1024
#define DEFAULT_PORT 8888

// Вразлива функція, що не перевіряє розмір вхідних даних
void process_data(char* buffer) {
    char local_buffer[64]; // Малий буфер для демонстрації переповнення

    printf("[*] Отримано дані від клієнта (%zu байт)\n", strlen(buffer));
    printf("[*] Копіювання даних у локальний буфер...\n");

    // Вразливий виклик - не перевіряє розмір
    strcpy(local_buffer, buffer); // <-- Вразливість переповнення буфера

    printf("[+] Дані оброблено: %s\n", local_buffer);
}

int main(int argc, char* argv[]) {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_size;
    char buffer[BUFFER_SIZE];
    int port = DEFAULT_PORT;

    // Обробка аргументів командного рядка
    if (argc > 1) {
        port = atoi(argv[1]);
        if (port <= 0 || port > 65535) {
            fprintf(stderr, "[-] Неправильний порт. Використовуйте порт від 1 до 65535.\n");
            return 1;
        }
    }

    printf("[*] Запуск вразливого сервера на порту %d...\n", port);

    // Створення сокета
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) {
        perror("[-] Помилка створення сокета");
        return 1;
    }

    // Налаштування параметрів сокета для повторного використання адреси
    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1) {
        perror("[-] Помилка setsockopt");
        close(server_fd);
        return 1;
    }

    // Налаштування адреси сервера
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    // Прив'язка сокета до адреси
    if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("[-] Помилка bind");
        close(server_fd);
        return 1;
    }

    // Переведення сокета в режим прослуховування
    if (listen(server_fd, 5) == -1) {
        perror("[-] Помилка listen");
        close(server_fd);
        return 1;
    }

    printf("[+] Сервер запущено. Очікування підключень...\n");

    // Основний цикл обробки підключень
    while (1) {
        client_addr_size = sizeof(client_addr);

        // Прийняття підключення
        client_fd = accept(server_fd, (struct sockaddr*)&client_addr, &client_addr_size);
        if (client_fd == -1) {
            perror("[-] Помилка accept");
            continue;
        }

        printf("[+] Підключено клієнта: %s:%d\n",
            inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Отримання даних від клієнта
        memset(buffer, 0, BUFFER_SIZE);
        ssize_t bytes_received = recv(client_fd, buffer, BUFFER_SIZE - 1, 0);

        if (bytes_received > 0) {
            buffer[bytes_received] = '\0'; // Гарантуємо нуль-термінатор

            // Вразлива обробка даних
            process_data(buffer);

            // Відправка відповіді
            const char* response = "Дані успішно оброблено\n";
            send(client_fd, response, strlen(response), 0);
        }
        else if (bytes_received == 0) {
            printf("[*] Клієнт відключився\n");
        }
        else {
            perror("[-] Помилка recv");
        }

        // Закриття з'єднання з клієнтом
        close(client_fd);
    }

    // Закриття серверного сокета (цей код не досягається в поточній реалізації)
    close(server_fd);
    return 0;
}