#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Hello from ARM payload!\n");
    return 0;
}