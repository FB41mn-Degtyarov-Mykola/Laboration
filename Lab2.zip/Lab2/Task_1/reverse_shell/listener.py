#!/usr/bin/env python3
import socket
import sys
import threading
import subprocess
import os
import signal
import time
import argparse

def setup_netcat_listener(port, verbose=True):
    """
    Запускає netcat у режимі прослуховування на вказаному порту.
    Повертає процес netcat для подальшого керування.
    """
    if verbose:
        print(f"[*] Запуск netcat слухача на порту {port}...")
    
    try:
        # Перевіряємо, чи встановлено netcat
        nc_path = subprocess.check_output(["which", "nc"]).decode().strip()
        if verbose:
            print(f"[+] Знайдено netcat за шляхом: {nc_path}")
    except subprocess.CalledProcessError:
        print("[-] Помилка: netcat не встановлено. Встановіть за допомогою 'apt-get install netcat'")
        sys.exit(1)
    
    # Запускаємо netcat у режимі прослуховування
    # -l: слухати, -v: детальний вивід, -n: не використовувати DNS, -p: порт
    nc_process = subprocess.Popen(
        ["nc", "-lvnp", str(port)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.PIPE,
        text=True,
        bufsize=1
    )
    
    # Даємо час на запуск
    time.sleep(1)
    
    # Перевіряємо, чи процес запущено
    if nc_process.poll() is not None:
        # Процес завершився - це помилка
        stdout, stderr = nc_process.communicate()
        print(f"[-] Помилка запуску netcat: {stderr}")
        sys.exit(1)
    
    if verbose:
        print(f"[+] Netcat слухач успішно запущено на порту {port}")
        print(f"[*] Очікування підключення...")
    
    return nc_process

def check_port_availability(port):
    """
    Перевіряє, чи вказаний порт доступний для використання.
    Повертає True, якщо порт вільний, інакше False.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    result = sock.connect_ex(('127.0.0.1', port))
    sock.close()
    return result != 0

def stream_process_output(process, prefix=""):
    """
    Виводить вивід процесу з певним префіксом.
    """
    for line in iter(process.stderr.readline, ''):
        if not line:
            break
        print(f"{prefix}{line}", end='', flush=True)

def main():
    parser = argparse.ArgumentParser(description="Налаштування слухача для reverse shell")
    parser.add_argument("-p", "--port", type=int, default=4444, help="Порт для прослуховування (за замовчуванням: 4444)")
    parser.add_argument("-q", "--quiet", action="store_true", help="Тихий режим (мінімальний вивід)")
    args = parser.parse_args()
    
    port = args.port
    verbose = not args.quiet
    
    # Перевіряємо, чи порт доступний
    if not check_port_availability(port):
        print(f"[-] Помилка: порт {port} вже використовується. Виберіть інший порт.")
        sys.exit(1)
    
    try:
        # Запускаємо netcat слухача
        nc_process = setup_netcat_listener(port, verbose)
        
        # Створюємо потік для виводу stderr netcat
        stderr_thread = threading.Thread(
            target=stream_process_output, 
            args=(nc_process, "[netcat] "),
            daemon=True
        )
        stderr_thread.start()
        
        # Очікуємо натискання Ctrl+C для завершення
        while True:
            try:
                # Перевіряємо, чи процес ще живий
                if nc_process.poll() is not None:
                    if verbose:
                        print("\n[*] Netcat слухач завершився")
                    break
                time.sleep(0.5)
            except KeyboardInterrupt:
                if verbose:
                    print("\n[*] Отримано сигнал переривання. Завершення роботи...")
                break
    
    finally:
        # Завершуємо netcat, якщо він ще запущений
        if 'nc_process' in locals() and nc_process.poll() is None:
            nc_process.terminate()
            try:
                nc_process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                nc_process.kill()
            if verbose:
                print("[*] Netcat слухач зупинено")

if __name__ == "__main__":
    main()